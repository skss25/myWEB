package com.movie.reservation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.movie.reservation.running.service.RunningService;

@Controller
public class MainController {
	@Autowired
	RunningService running; //구현 객체를 스프링 컨테이너에 등록하여야 제대로 동작함
	
	
	/* RequestMapping 예제 (path는 value 속성을 사용하도록 바뀌었음)
	 * https://noritersand.tistory.com/475
	 * */
	@RequestMapping(value= {"/running", "/reserv"}, method=RequestMethod.GET)
	public String test() {
		System.out.println("Main 페이지가 열립니다.");
		
		running.getMovieInfos();
		return "index";
	}
}
