package com.movie.reservation.running.service;

public interface RunningService {
	
	public void getMovieInfos();
	public void searchMovieInfo();
}
