package com.movie.reservation.running.service;

public class RunningServiceImpl implements RunningService {

	@Override
	public void getMovieInfos() {
		System.out.println("상영 영화 정보를 가져옵니다.");
	}

	@Override
	public void searchMovieInfo() {
		System.out.println("상영 영화 정보를 찾습니다.");
	}
}
