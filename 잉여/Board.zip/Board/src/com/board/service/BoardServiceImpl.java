package com.board.service;

import java.util.List;

import com.board.dao.BoardDao;
import com.board.dao.BoardDaoImpl;
import com.board.dto.Member;

public class BoardServiceImpl implements BoardService {
	BoardDao bDao = new BoardDaoImpl();
	
	@Override
	public void create(Member member) {
		bDao.create(member);
	}

	@Override
	public int delete(Member member) {
		return bDao.delete(member);
	}

	@Override
	public int update(Member member) {
		return bDao.update(member);
	}

	@Override
	public List<Member> read() {
		return bDao.read();
	}

}
