package com.board.main;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.controller.*;

@WebServlet("/")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HashMap<String, BoardController> hashMap = null;
	
    @Override
	public void init(ServletConfig config) throws ServletException {
    	/*
    	 * DispatcherServlet의 대용으로 작성
    	 * 참고 자료
    	 * http://arabiannight.tistory.com/entry/%EC%9E%90%EB%B0%94Java-%EC%9E%90%EB%B0%94-HashMap-%EC%9D%B4%EB%9E%80
    	 * */
    	hashMap = new HashMap<String, BoardController>();
    	hashMap.put("create", new BoardControllerCreate());
    	hashMap.put("delete", new BoardControllerDelete());
    	hashMap.put("read", new BoardControllerRead());
    	hashMap.put("update", new BoardControllerUpdate());
	}

	public MainServlet() {super();}

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		/* 참고 자료
		 * https://docs.oracle.com/javaee/7/api/index.html?javax/servlet/package-summary.html
		 * http://jsp-making.tistory.com/133
		 */
		BoardController bc = null;
		String uri=req.getRequestURI();
		String[] tokens = uri.split("/");
	}
}
