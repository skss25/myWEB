package com.board.dao;

import java.util.List;

import com.board.dto.Member;

public class BoardDaoImpl implements BoardDao {

	@Override
	public void create(Member member) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int delete(Member member) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Member member) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Member> read() {
		// TODO Auto-generated method stub
		return null;
	}
}
