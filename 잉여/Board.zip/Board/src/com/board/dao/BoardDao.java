package com.board.dao;

import java.util.List;

import com.board.dto.Member;

public interface BoardDao {
	public void create(Member member);
	public int delete(Member member);
	public int update(Member member);
	public List<Member> read();
}
