package com.board.controller;

public interface BoardController {
	public void service();
}
