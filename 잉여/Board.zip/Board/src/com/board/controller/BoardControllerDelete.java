package com.board.controller;

public class BoardControllerDelete implements BoardController {

	@Override
	public void service() {
		// TODO Auto-generated method stub
		
	}
	
}
