package com.board.controller;

public class BoardControllerCreate implements BoardController {

	@Override
	public void service() {
		// TODO Auto-generated method stub
		
	}
	
}
