package com.board.dto;

public class Member {
	String id;
	String password;
}
