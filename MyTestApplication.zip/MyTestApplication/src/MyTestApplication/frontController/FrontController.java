package MyTestApplication.frontController;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import MyTestApplication.controller.Controller;
import MyTestApplication.controller.TestAddController;
import MyTestApplication.controller.TestCheckController;
import MyTestApplication.controller.TestContentController;
import MyTestApplication.controller.TestListController;

@WebServlet("*.action")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String charset=null;
	HashMap<String, Controller> map=null;

	@Override
	public void init() throws ServletException {
		charset="UTF-8";
		map=new HashMap<String, Controller>();
		map.put("list.action", new TestListController());
		map.put("content.action", new TestContentController());
		map.put("check.action", new TestCheckController());
		map.put("add.action", new TestAddController());
	}

	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		request.setCharacterEncoding(charset);
		List<String> tokens=new ArrayList<String>();
		String path=null;
		String requestURI=request.getRequestURI();
		StringTokenizer st=new StringTokenizer(requestURI, "/");
		
		while(st.hasMoreTokens()) {
			tokens.add(st.nextToken());
		}
		
		path = tokens.get(1);
		System.out.println(path);
		Controller con=map.get(path);
		
		if(con!=null) {
			con.execute(request, response);
		}
	}
}
