package MyTestApplication.serviceImpl;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import MyTestApplication.controller.StringProcessorUtil;
import MyTestApplication.dao.TestDao;
import MyTestApplication.daoImpl.TestDaoImpl;
import MyTestApplication.dto.testContentDto;
import MyTestApplication.dto.testPageDto;
import MyTestApplication.dto.testTitleDto;
import MyTestApplication.service.TestApplicationService;

public class TestApplicationServiceImpl implements TestApplicationService {

	@Override
	public List<testTitleDto> getTitlesInfo(HttpServletRequest request) {
		int pageNum = 0, start = 0, end = 0;
		int linkStart = 0;
		
		int LIST_MAX=5;
		int LINK_MAX=5; //ǥ���� ��ũ�� �ִ� ��
		
		TestDao dao=null; //DB ���� ��ü
		List<testTitleDto> titles=null; //DB�� �����ϴ� ��ũ�� ����Ʈ
		List<testTitleDto> titleList=null; //ȭ�鿡 ǥ���� ��ũ�� ����Ʈ
		String page=null; //Ŭ���� ��ũ�� ������ ��ȣ
		
		int linkCount=0; //ȭ�鿡 ǥ���� ��ũ�� ����
		int titleCount=0; //����� ���� ������ ����
		
		page=request.getParameter("page");
		if(page!=null) { 
			pageNum=Integer.parseInt(page);
		}
		
		dao=new TestDaoImpl();
		titles=dao.getTitles();
		titleCount=titles.size(); //�������� ����
		if(titleCount != 0) {
			linkCount=(titleCount / LIST_MAX);
			//�� �Խù��� ������ MAX COUNT�� �������� �� �������� 0�� �ƴ϶��...
			if((titleCount % LIST_MAX) != 0) {
				linkCount+=1;
			}
			
			//��ũ�� �������� ��´�.
			if(pageNum == 0) {
				linkStart=0;
			}else if(pageNum % LINK_MAX == 0){
				linkStart=pageNum;
			}else {
				linkStart=(pageNum-(pageNum % LINK_MAX));
			}
			
			//�ش� �������� ǥ���� ����Ʈ���� List ��ü�� �����Ѵ�.
			start = pageNum * MAX_COUNT;
			end = (pageNum+1) * MAX_COUNT;
			titleList=new LinkedList<testTitleDto>();
			for(int objCount=titleCount; start<objCount; start++) {
				if(start < end) {
					titleList.add(titles.get(start));
				}else {
					break;
				}
			}
		}
		request.setAttribute("linkStart", linkStart);
		request.setAttribute("linkCount", linkCount);
		request.setAttribute("titleLinks", titleList);
		
		return titleList;
	}

	@Override
	public List<testContentDto> getContentsInfo(HttpServletRequest request) { //����� �ܾ� ����Ʈ�� �о���� �޼ҵ�
		TestDao dao = null;
		List<testContentDto> lists = null;
		testPageDto pageData = null; //testPage.jsp�� ǥ���� �����͸� �����ϰ� �ִ� ��ü
		
		String titleId=null, pageType=null, pageMethod=null; //���� id, ������ ����, �׽�Ʈ ���
		String[] words=null;
		String[] means=null;
		int len=0, i=0;
		
		dao = new TestDaoImpl();
		titleId = request.getParameter("id");
		
		pageData = dao.getAllContents(titleId); //DB�κ��� id���� �ش��ϴ� ����� �ܾ� ����Ʈ�� �о�´�.
		lists=pageData.getLists();
		len=lists.size();
		
		if(len != 0 && pageData.getLists() != null) {
			pageType = request.getParameter("type");
			if(pageType.equals("test")) {
				pageMethod = request.getParameter("method");
				
				
				if(pageMethod.equals("word")) {
					words = new String[len];
					for(testContentDto item : lists) {
						words[i] = item.getWord();
						i++;
					}
					request.setAttribute("words", words);
				}else if(pageMethod.equals("mean")) {
					means = new String[len];
					for(testContentDto item : lists) {
						means[i] = item.getMean();
						i++;
					}
					request.setAttribute("means", means);
				}
				request.setAttribute("pageMethod", pageMethod);
			}else if(pageType.equals("show")) {
				try {
					words = new String[len];
					means = new String[len];
					for(testContentDto item : lists) {
						words[i] = new String(item.getWord());
						means[i] = new String(item.getMean());
						i++;
					}
					request.setAttribute("words", words);
					request.setAttribute("means", means);
				}catch(Exception e) {
					System.out.println("type show Exception Error!!");
				}
			}
			
			request.setAttribute("title", pageData.getTitle().getTitle());
			request.setAttribute("titleId", pageData.getTitle().getTitleId());
			
			request.setAttribute("pageType", pageType);
			request.setAttribute("len", len);
		}
		
		return pageData.getLists();
	}

	@Override
	public void addTestInfo(HttpServletRequest request){
		TestDao dao = null;
		testTitleDto title = null;
		List<testContentDto> contents = null;
		
		StringProcessorUtil stu = null;
		String[] words=null;
		String[] means=null;
		int wordsCount=0;
		testContentDto content = null;
		
		/*���� ������ �����Ѵ�.*/
		dao=new TestDaoImpl();
		title=new testTitleDto();
		title.setTitle(request.getParameter("title"));
		title.setRegister(request.getParameter("register"));
		title.setCount(Integer.parseInt(request.getParameter("count")));
		title.setLang(request.getParameter("lang"));
		
		/*�ش� ������ content�� �����Ѵ�.*/
		contents=new ArrayList<testContentDto>();
		words = request.getParameterValues("word");
		means = request.getParameterValues("mean");
		wordsCount=title.getCount();
		
		stu=new StringProcessorUtil();
		try {
			for(int i = 0, len = words.length; i < len; i++) {
				content=new testContentDto(); //�ܾ ������ ��ü�� ����
				content.setWord(words[i]);
				//���ڿ��� �����ؾ� �Ѵ�("������ �����ϴ�, ����" -> "�����������Ѵ�, ����")
				//means[i] = stu.getProcessedString(means[i]);
				content.setMean(means[i]);
					
				contents.add(content);
			}
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Array Exception!!!");
			e.printStackTrace();
		}
		
		System.out.println("affected row(s): "+dao.addTitleContent(title, contents));
	}

	@Override
	public int checkTest(HttpServletRequest request) {
		TestDao dao = null;
		String titleId=null, method=null, checkFlag = null, str=null;
		String[] inputs = null;
		testPageDto pdto = null;
		int wordsCount = 0, myScore = 0;
		
		dao = new TestDaoImpl();
		titleId = request.getParameter("id");
		method = request.getParameter("method");
		
		inputs=request.getParameterValues("mean");
		pdto = dao.getAllContents(titleId);
		wordsCount = pdto.getLists().size();
		
		try {
		for(int i=0, len=wordsCount; i<len; i++) {
			if(method.equals("word")) {
				str = pdto.getLists().get(i).getMean();
			}else if(method.equals("mean")) {
				str = pdto.getLists().get(i).getWord();
			}
			myScore += getScore(inputs[i], str, method);
		}
		
		checkFlag = "Checked";
		request.setAttribute("score", myScore);
		request.setAttribute("count", wordsCount);
		request.setAttribute("IsChecked", checkFlag);
		}catch(Exception e) {
			System.out.println("checkTest Exception!!");
		}
		
		return myScore;
	}

	@Override
	public int getScore(String input, String target, String method) { /*������ ��ȯ�ϴ� �޼ҵ�*/
		
		StringProcessorUtil stu = new StringProcessorUtil();
		String[] inputs = null;
		String processedTarget = null;
		int score=1;
		
		try {
		if(method.equals("word")) {
			inputs = stu.getProcessedString(input).split(",");
			processedTarget = stu.getProcessedString(target);
			for(int i=0, len = inputs.length; i<len; i++) {
				if(!processedTarget.contains(inputs[i])) {
					score = 0;
					break;
				}
			}
		}else if(method.equals("mean")) {
			if(input.equals(target)) {
				score = 0;
			}
		}
		}catch(Exception e) {
			System.out.println("getScore Exception!!");
		}
		
		return score;
	}

	@Override
	public int removeTest(HttpServletRequest request) throws NullPointerException{
		String postId = null;
		TestDao dao = null;
		
		try {
			postId=request.getParameter("id");
			dao= new TestDaoImpl();
			dao.deleteTest(postId);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	
}
