package MyTestApplication.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import MyTestApplication.service.TestApplicationService;
import MyTestApplication.serviceImpl.TestApplicationServiceImpl;

public class TestListController implements Controller {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		TestApplicationService as = new TestApplicationServiceImpl();
		if(as.getTitlesInfo(req) == null) {
			System.out.println("ǥ���� �����Ͱ� �������� �ʽ��ϴ�.");
		}
		
		ForwardControl fc=new ForwardControl();
		fc.forward(req, res, "./main.jsp");
	}

}
