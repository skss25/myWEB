package MyTestApplication.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import MyTestApplication.service.TestApplicationService;
import MyTestApplication.serviceImpl.TestApplicationServiceImpl;

public class TestListController implements Controller {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		TestApplicationService as = new TestApplicationServiceImpl();
		as.getTitlesInfo(req);
		
		ForwardControl fc=new ForwardControl();
		fc.forward(req, res, "./main.jsp");
	}

}
