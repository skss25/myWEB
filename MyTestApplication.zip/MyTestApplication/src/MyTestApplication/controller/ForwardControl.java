package MyTestApplication.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ForwardControl extends HttpServlet{
	public void forward(HttpServletRequest request, HttpServletResponse response, String uri) {
		try {
			RequestDispatcher rd=request.getRequestDispatcher(uri);
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
}
