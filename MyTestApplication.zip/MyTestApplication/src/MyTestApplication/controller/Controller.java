package MyTestApplication.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public interface Controller {
	public abstract void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException;
}
