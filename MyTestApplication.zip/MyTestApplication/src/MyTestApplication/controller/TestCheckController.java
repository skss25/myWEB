package MyTestApplication.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import MyTestApplication.service.TestApplicationService;
import MyTestApplication.serviceImpl.TestApplicationServiceImpl;

public class TestCheckController implements Controller {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		TestApplicationService as=new TestApplicationServiceImpl();
		String id=null, method=null;
		as.checkTest(req);
		
		id=req.getParameter("id");
		method=req.getParameter("method");
		
		ForwardControl fc=new ForwardControl();
		fc.forward(req, res, "content.action?id="+id+"&type=test&method="+method);
	}
}
