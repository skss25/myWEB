package MyTestApplication.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import MyTestApplication.dto.testContentDto;
import MyTestApplication.dto.testTitleDto;

public interface TestApplicationService {
	public static final int MAX_COUNT=5;
	public abstract List<testTitleDto> getTitlesInfo(HttpServletRequest request);
	public abstract List<testContentDto> getContentsInfo(HttpServletRequest request);
	public abstract void addTestInfo(HttpServletRequest request);
	
	public abstract int checkTest(HttpServletRequest request);
	public abstract int getScore(String input, String target, String method);
	
	public abstract int removeTest(HttpServletRequest request);
}
