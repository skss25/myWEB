package MyTestApplication.daoImpl;

import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.*;
import javax.sql.*;
import java.sql.*;

import com.mysql.jdbc.Connection;

import MyTestApplication.dao.TestDao;
import MyTestApplication.dto.testContentDto;
import MyTestApplication.dto.testPageDto;
import MyTestApplication.dto.testTitleDto;

public class TestDaoImpl implements TestDao {

	@Override
	public List<testTitleDto> getTitles() {
		List<testTitleDto> titles=new ArrayList<testTitleDto>();
		String sql="SELECT * FROM titletbl";
		ResultSet rs=null;
		
		try {
			Class.forName(JDBC_DRIVER);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try(
			Connection conn=(Connection) DriverManager.getConnection(DBURL, DBID, DBPWD);
			PreparedStatement ps=conn.prepareStatement(sql)
		){
			rs=ps.executeQuery();
			while(rs.next()) {
				testTitleDto dto=new testTitleDto();
				dto.setTitleId(rs.getInt("titleid"));
				dto.setTitle(rs.getString("title"));
				dto.setCount(rs.getInt("count"));
				dto.setRegDate(rs.getString("regdate"));
				dto.setRegister(rs.getString("register"));
				dto.setLang(rs.getString("lang"));
				
				titles.add(dto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return titles;
	}

	@Override
	public testTitleDto getCertainTtitle(String titleId) {
		testTitleDto curTitle = new testTitleDto();
		String sql="SELECT * FROM titletbl WHERE titleid = ?";
		ResultSet rs=null;
		
		try {
			Class.forName(JDBC_DRIVER);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try(
			Connection conn=(Connection) DriverManager.getConnection(DBURL, DBID, DBPWD);
			PreparedStatement ps=conn.prepareStatement(sql)
		){
			ps.setString(1, titleId);
			rs=ps.executeQuery();
			while(rs.next()) {
				curTitle.setTitleId(rs.getInt("titleid"));
				curTitle.setTitle(rs.getString("title"));
				curTitle.setCount(rs.getInt("count"));
				curTitle.setRegDate(rs.getString("regdate"));
				curTitle.setRegister(rs.getString("register"));
				curTitle.setLang(rs.getString("lang"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return curTitle;
	}

	@Override
	public testPageDto getContents(String titleId) {
		testPageDto pageData = null;
		testTitleDto title = null;
		List<testContentDto> contents = new ArrayList<testContentDto>();
		String sql = "SELECT * FROM vocabtbl WHERE id = ?";
		ResultSet rs=null;
		
		try {
			Class.forName(JDBC_DRIVER);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try(
			Connection conn=(Connection) DriverManager.getConnection(DBURL, DBID, DBPWD);
			PreparedStatement ps=conn.prepareStatement(sql)
		){
			title = getCertainTtitle(titleId);
			
			ps.setString(1, titleId);
			rs=ps.executeQuery();
			while(rs.next()) {
				testContentDto content=new testContentDto();
				content.setContentId(rs.getInt("ID"));
				content.setWord(rs.getString("word"));
				content.setMean(rs.getString("mean"));
				
				contents.add(content);
			}
			
			pageData = new testPageDto(title, contents);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return pageData;
	}

	@Override
	public int addTitle(testTitleDto title) {
		List<testContentDto> contents = new ArrayList<testContentDto>();
		String sql = "INSERT INTO titletbl VALUES(DEFAULT,?,?,DATE(NOW()),?,?)"; 
		int count=0;
		try {
			Class.forName(JDBC_DRIVER);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try(
			Connection conn=(Connection) DriverManager.getConnection(DBURL, DBID, DBPWD);
			PreparedStatement ps=conn.prepareStatement(sql)
		){
			ps.setString(1, title.getTitle());
			ps.setInt(2, title.getCount());
			ps.setString(3, title.getRegister());
			ps.setString(4, title.getLang());
			count = ps.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return count;
	}

	@Override
	public int getTitleId(String title) {
		List<testContentDto> contents = new ArrayList<testContentDto>();
		String sql = "SELECT * FROM titletbl WHERE title = ?";
		ResultSet rs=null;
		int titleId = 0;
		
		try {
			Class.forName(JDBC_DRIVER);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try(
			Connection conn=(Connection) DriverManager.getConnection(DBURL, DBID, DBPWD);
			PreparedStatement ps=conn.prepareStatement(sql)
		){
			ps.setString(1, title);
			rs = ps.executeQuery();
			while(rs.next()) {
				titleId=rs.getInt("titleId");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return titleId;
	}

	@Override
	public int addTitleContent(testTitleDto title, List<testContentDto> contents) {
		String sql = "INSERT INTO vocabtbl VALUES(?,?,?)";
		int count = 0;
		int titleId=0;
		
		try {
			Class.forName(JDBC_DRIVER);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try(
			Connection conn=(Connection) DriverManager.getConnection(DBURL, DBID, DBPWD);
			PreparedStatement ps=conn.prepareStatement(sql)
		){
			addTitle(title); //���� ���� ����
			titleId=getTitleId(title.getTitle()); //����� ���� ���� id�� ���� 
			
			for(testContentDto content : contents) {
				content.setContentId(titleId); //id�� ���� �� ����
				ps.setInt(1, content.getContentId());
				ps.setString(2, content.getWord());
				ps.setString(3, content.getMean());
				count+=ps.executeUpdate();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return count;
	}

	@Override
	public int deleteTest(String testId) {
		String sql1 ="DELETE FROM titleTBL WHERE titleID = ?";
		String sql2 ="DELETE FROM vocabTBL WHERE ID = ?";
		int count = 0;
		
		try {
			Class.forName(JDBC_DRIVER);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try(
			Connection conn=(Connection) DriverManager.getConnection(DBURL, DBID, DBPWD);
			PreparedStatement ps1=conn.prepareStatement(sql1);
			PreparedStatement ps2=conn.prepareStatement(sql2)
		){
			ps1.setString(1, testId);
			ps2.setString(1, testId);
			
			count = ps2.executeUpdate();
			count += ps1.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return count;
	}
}
