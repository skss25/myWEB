package MyTestApplication.dao;

import java.util.List;

import MyTestApplication.dto.testContentDto;
import MyTestApplication.dto.testTitleDto;

public interface TestDao {
	public static final String JDBC_DRIVER="com.mysql.jdbc.Driver";
	public static final String DBURL="jdbc:mysql://localhost:3306/mydb?useSSL=false&characterEncoding=euckr";
	public static final String DBID="wannacode";
	public static final String DBPWD="wannacode";
	
	public abstract List<testTitleDto> getTitles(); //���� ��ȸ �޼ҵ�
	
	public abstract testTitleDto getCertainTtitle(String titleId); //Ư�� �׸� ��ȸ �޼ҵ�
	public abstract List<testContentDto> getContents(String titleId);
	
	public abstract int addTitle(testTitleDto title);
	public abstract int getTitleId(String title);
	public abstract int addTitleContent(testTitleDto title, List<testContentDto> contents);
}
