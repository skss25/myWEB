package MyTestApplication.dto;

public class testContentDto {
	private int contentId;
	private String word;
	private String mean;
	
	public testContentDto() {}
	
	public testContentDto(int contentId, String word, String mean) {
		this.contentId = contentId;
		this.word = word;
		this.mean = mean;
	}

	public int getContentId() {
		return contentId;
	}
	public void setContentId(int contentId) {
		this.contentId = contentId;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public String getMean() {
		return mean;
	}
	public void setMean(String mean) {
		this.mean = mean;
	}
	@Override
	public String toString() {
		return "testContentDto [contentId=" + contentId + ", word=" + word + ", mean=" + mean + "]";
	}
	
	
}
