package MyTestApplication.dto;

import java.util.List;

public class testPageDto { /*�ܾ��� ����� ��ϵ��� �����ϴ� ��ü*/
	testTitleDto title = null;
	List<testContentDto> lists = null;
	
	public testPageDto(testTitleDto title, List<testContentDto> lists) {
		this.title = title;
		this.lists = lists;
	}
	public testTitleDto getTitle() {
		return title;
	}
	public void setTitle(testTitleDto title) {
		this.title = title;
	}
	public List<testContentDto> getLists() {
		return lists;
	}
	public void setLists(List<testContentDto> lists) {
		this.lists = lists;
	}
}
