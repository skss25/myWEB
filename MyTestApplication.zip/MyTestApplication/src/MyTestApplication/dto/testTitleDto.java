package MyTestApplication.dto;

public class testTitleDto {
	private int titleId;
	private String title;
	private int count;
	private String regDate;
	private String register;
	private String lang;
	
	public testTitleDto() {}

	public testTitleDto(int titleId, String title, int count, String regDate, String register, String lang) {
		this.titleId = titleId;
		this.title = title;
		this.count = count;
		this.regDate = regDate;
		this.register = register;
		this.lang = lang;
	}
	
	public int getTitleId() {
		return titleId;
	}
	public void setTitleId(int titleId) {
		this.titleId = titleId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getRegister() {
		return register;
	}
	public void setRegister(String register) {
		this.register = register;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	@Override
	public String toString() {
		return "testTitleDto [titleId=" + titleId + ", title=" + title + ", count=" + count + ", regDate=" + regDate
				+ ", register=" + register + ", lang=" + lang + "]";
	}
	
	
}
