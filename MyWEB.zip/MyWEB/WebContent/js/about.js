
var hobbyLists=document.querySelectorAll(".about-section .about-list .hobby-list li");
var majorLists=document.querySelectorAll(".about-section .about-list .major-list li");
var interestLists=document.querySelectorAll(".about-section .about-list .interest-list li");

var hobbyBtn=document.querySelector(".about-section .about-list .hobby-list h1");
var majorBtn=document.querySelector(".about-section .about-list .major-list h1");
var interestBtn=document.querySelector(".about-section .about-list .interest-list h1");

var hBtnClicked=0;
var mBtnClicked=0;
var iBtnClicked=0;

//BtnClicked 매개변수를 선언해준 이유는 버튼의 종류를 통일하기 위해서이다.
function showList(myLists, BtnClicked){
  if(BtnClicked != 1){
    for(var i=0; i<myLists.length; i++){
      myLists[i].style.visibility="visible";
      myLists[i].style.opacity="1.0";
    }
    BtnClicked+=1;
  }else{
    for(var i=0; i<myLists.length; i++){
      myLists[i].style.visibility="hidden";
      myLists[i].style.opacity="0.0";
    }
    BtnClicked=0;
  }

  return BtnClicked;
}

hobbyBtn.addEventListener('click', function(){
  hBtnClicked=showList(hobbyLists, hBtnClicked);
});

majorBtn.addEventListener('click', function(){
  mBtnClicked=showList(majorLists, mBtnClicked);
});

interestBtn.addEventListener('click', function(){
  iBtnClicked=showList(interestLists, iBtnClicked);
});
