
  /*ul, li 객체와 길이 구하기*/
  var canvas=document.querySelector('.canvas');
  var container=document.querySelector('.canvas .visual');
  var images=document.querySelectorAll('.canvas .visual > li');
  var image=document.querySelectorAll('.canvas .visual li img');

  for(var i=0; i<image.length; i++){
    image[i].style.width="1080px";
    image[i].style.height="400px";
  }

  /*클론 작성후 추가*/
  var lImageClone=images[0].cloneNode(true);
  container.appendChild(lImageClone);

  /*이미지들의 크기를 구하여, 하나의 밴드를 만들어준다.*/
  images=document.querySelectorAll('.canvas .visual > li');
  var elemWidth=parseInt(getComputedStyle(images[0]).width);
  var listLen=images.length;
  container.style.width=(elemWidth * listLen)+"px";

  var currentIdx=0;
  var movePos=0;
  var myTimerId=setInterval(function(){
    currentIdx+=1;
    movePos=currentIdx*elemWidth;
    container.style.transitionDuration="0.6s";
    container.style.transform="translate(-"+movePos+"px)";

    if(movePos === (listLen*elemWidth)){ //if절이 완료된 후, 2초를 더 기다려야 한다.
      currentIdx=0;
      container.style.transitionDuration="0s";
      container.style.transform="translate(0px)";
    }
  }, 1000*2);
