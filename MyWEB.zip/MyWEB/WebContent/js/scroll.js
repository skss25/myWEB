var navBtns=document.querySelectorAll("#main-right .list-wrapper ul li");

//클릭 이벤트 발생시 이동할 요소의 객체
navBtns[0].addEventListener('click', function(){
  const positionToMove=document.querySelector("#top");
  positionToMove.scrollIntoView({ block: 'start',  behavior: 'smooth' });
});


navBtns[1].addEventListener('click', function(){
  const positionToMove=document.querySelector("#middle .about-section .about-top");
  positionToMove.scrollIntoView({ block: 'start',  behavior: 'smooth' });
});

navBtns[2].addEventListener('click', function(){
  const positionToMove=document.querySelector("#middle .about-section .about-list");
  positionToMove.scrollIntoView({ block: 'start',  behavior: 'smooth' });
});

navBtns[3].addEventListener('click', function(){
  const positionToMove=document.querySelector("#middle .contact-form-section");
  positionToMove.scrollIntoView({ block: 'start',  behavior: 'smooth' });
});

navBtns[4].addEventListener('click', function(){
  const positionToMove=document.querySelector("#bottom");
  positionToMove.scrollIntoView({ block: 'start',  behavior: 'smooth' });
});
