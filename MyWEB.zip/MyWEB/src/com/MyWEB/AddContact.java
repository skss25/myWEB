package com.MyWEB;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyWEB.dao.contactDAO;
import com.MyWEB.dto.contact;

public class AddContact extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AddContact() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); //Request ��ü�� ���� �����ϱ� ���� �ݵ�� �� �޼ҵ带 ȣ������־�� �Ѵ�.
		contactDAO dao=new contactDAO(); //data access object ����
		contact dto=new contact(); //data object ����
		
		dto.setName(request.getParameter("name"));
		dto.setPhone(request.getParameter("phone"));
		dto.setEmail(request.getParameter("email"));
		dto.setMessage(request.getParameter("message"));
		
		dao.add(dto);
		response.sendRedirect("./html/index.html");
	}
}
